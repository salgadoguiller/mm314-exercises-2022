/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.time.LocalDate;

/**
 *
 * @author Alex Galo
 */
public class Inventario {
    private String numero ;
    private Producto producto ; 
    private String fecha ; 

    
    public Inventario(String numero, Producto producto, String fecha) {
        this.numero = numero;
        this.producto = producto;
        this.fecha = fecha;
    }
    
    //FALTAN GETS Y SETS

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }
    
}