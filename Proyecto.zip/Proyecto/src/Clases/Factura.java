/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.Date;


/**
 *
 * @author Calix Gonzalez
 */
public class Factura {
          private String numFactura;
	private Empleados empleado;
	private String fechaEmision;
        private String hora;
	private int cantidadProducto;   
        private Producto producto ;
        
        
    public Factura() {		
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getFechaEmision() {
        return fechaEmision;
    }

    public void setFechaEmision(String fechaEmision) {
        this.fechaEmision = fechaEmision;
    }

    public String getNumFactura() {
        return numFactura;
    }

    public void setNumFactura(String numFactura) {
        this.numFactura = numFactura;
    }
    
    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }
	


        
	public Empleados getEmpleado() {
		return empleado;
	}

	public void setEmpleado(Empleados empleado) {
		this.empleado = empleado;
	}
	

	public int getCantidadProducto() {
		return cantidadProducto;
	}

	public void setCantidadProducto(int cantidadProducto) {
		this.cantidadProducto = cantidadProducto;
	}
	
	
	
	@Override
	public String toString() {
		return "Factura [numFactura=" + numFactura + " , empleado=" + empleado
				+ ", fechaEmision=" + fechaEmision + ", cantidadProducto=" + cantidadProducto + "]" ;  
				
	}

}
