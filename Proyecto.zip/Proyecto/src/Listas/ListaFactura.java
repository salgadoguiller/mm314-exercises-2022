/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Listas;

import Clases.Factura;
import java.util.LinkedList;

/**
 *
 * @author ACalix
 */
public class ListaFactura {
      private LinkedList<Factura>listFactura = new LinkedList<>();

    public ListaFactura() {
    }
      
    public boolean eliminar(int posicion) {
		listFactura.remove(posicion);
		return true;
	}

	public boolean modificar(Factura Modificado, int posicion) {
		listFactura.set(posicion, Modificado);
		return true;
	}

	public boolean agregar(Factura obje) {
		listFactura.add(obje);
		return true;
	}

	public Factura get(int posicion) {
		return listFactura.get(posicion);
	}

         public Object[][] getArrayGestion(){
                int i, tamanioLista;
                tamanioLista=this.listFactura.size();
		Object [][] array=new Object[tamanioLista][3];
		for(i=0;i<tamanioLista;i++) { 
                    array[i][0] = this.listFactura.get(i).getNumFactura();
                    array[i][1] = this.listFactura.get(i).getProducto().getNombre();
                    array[i][2] = this.listFactura.get(i).getProducto().getPrecio();
		}
                return array;
        }
}
