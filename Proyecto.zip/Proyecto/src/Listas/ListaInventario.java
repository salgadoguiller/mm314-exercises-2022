/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Listas;

import Clases.Inventario;
import java.io.Serializable;
import java.util.LinkedList;

/**
 *
 * @author ACalix
 */
public class ListaInventario implements Serializable {
    private LinkedList<Inventario>listInventario = new LinkedList<>();

    public ListaInventario() {
    }

   	public boolean eliminar(int posicion) {
		listInventario.remove(posicion);
		return true;
	}

	public boolean modificar(Inventario Modificado, int posicion) {
		listInventario.set(posicion, Modificado);
		return true;
	}

	public boolean agregar(Inventario obj) {
		listInventario.add(obj);
		return true;
	}

	public Inventario get(int posicion) {
		return listInventario.get(posicion);
	}

         public Object[][] getArrayGestion(){
                int i, tamanioLista;
                tamanioLista=this.listInventario.size();
		Object [][] array=new Object[tamanioLista][4];
		for(i=0;i<tamanioLista;i++) { 
                    array[i][0] = this.listInventario.get(i).getNumero();
                    array[i][1] = this.listInventario.get(i).getProducto().getNombre();
                    array[i][2] = this.listInventario.get(i).getProducto().getCategoria();
                    array[i][3] = this.listInventario.get(i).getFecha();
		}
                return array;
        }
    
}
