package Listas;

import Clases.Categoria;
import java.io.Serializable;
import java.util.LinkedList;
import javax.swing.DefaultComboBoxModel;

public class GestionCategoria implements Serializable {
	private LinkedList<Categoria> lstCategoria=new LinkedList<>();
        
	public GestionCategoria() {
		// TODO Auto-generated constructor stub
	}
	
	public boolean Agregar(Categoria objCategoria) {
		this.lstCategoria.add(objCategoria);
		return true;
	}

	public boolean Eliminar(int posicion) {
		this.lstCategoria.remove(posicion);
		return true;
	}
	

	public boolean Modificar(Categoria objModificado, int posicionModificar) {
		this.lstCategoria.set(posicionModificar, objModificado);
		return true;
	}

	public int BuscarPorDescripcion(String descripcion) {
		int posicionEncontrada=-1;
		int i, tamanioLista;
		tamanioLista=this.lstCategoria.size();//tamanio de la lista
		for(i=0;i<tamanioLista;i++) { //Iniciar un ciclo para recorrer toda la lista
			if(this.lstCategoria.get(i).getDescripcion().equals(descripcion)){//comparar la descripcion del objeto contenido en la lista con el parametro enviado
				posicionEncontrada=i;//En caso de encontrarlo
				break;
			}
		}
		return posicionEncontrada;
	}


	
	/**
	 * 
	 * Retorna el objeto seg�n la posicion enviada
	 * @param posicion
	 * @return
	 */
	public Categoria getCategoria(int posicion) {
		return this.lstCategoria.get(posicion);
	}
	
	/**
	 * Imprimir informacion de la lista
	 * @author OHernandez
	 * @since 17Julio2019
	 * 
	 */
	public void imprimir() {
		System.out.println(this.lstCategoria);
	}
	
        
        public Object[][] getArrayGestion(){
                int i, tamanioLista;
                tamanioLista=this.lstCategoria.size();//tamanio de la lista
		Object [][] array=new Object[tamanioLista][2];
		for(i=0;i<tamanioLista;i++) { //Iniciar un ciclo para recorrer toda la lista
			array[i][0]=this.lstCategoria.get(i).getCodigo();
                        array[i][1]=this.lstCategoria.get(i).getDescripcion();
                        
		}
                return array;
        }
        

        
        public DefaultComboBoxModel getComboboxModel(){
            int i, tamanioLista;
                tamanioLista=this.lstCategoria.size();//tamanio de la lista
		DefaultComboBoxModel modelo=new DefaultComboBoxModel();
		for(i=0;i<tamanioLista;i++) { //Iniciar un ciclo para recorrer toda la lista
			modelo.addElement(this.lstCategoria.get(i).getDescripcion());
		}
                return modelo;
        }

}





























