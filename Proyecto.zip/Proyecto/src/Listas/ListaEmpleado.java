package Listas;

import Clases.Empleados;
import java.io.Serializable;
import java.util.LinkedList;
import javax.swing.DefaultComboBoxModel;

public class ListaEmpleado implements Serializable {

	private LinkedList<Empleados>listEmpleado = new LinkedList<>();

	public ListaEmpleado() {
		
	}

	public boolean eliminarEmpleado(int posicion) {
		listEmpleado.remove(posicion);
		return true;
	}

	public boolean modificarEmpleado(Empleados Modificado, int posicion) {
		listEmpleado.set(posicion, Modificado);
		return true;
	}

	public boolean agregarEmpleado(Empleados objeEmpleado) {
		listEmpleado.add(objeEmpleado);
		return true;
	}

	public Empleados get(int posicion) {
		return listEmpleado.get(posicion);
	}

         public Object[][] getArrayGestion(){
                int i, tamanioLista;
                tamanioLista=this.listEmpleado.size();
		Object [][] array=new Object[tamanioLista][2];
		for(i=0;i<tamanioLista;i++) { 
                        array[i][0]=this.listEmpleado.get(i).getNombre();
                        array[i][1]=this.listEmpleado.get(i).getApellidos();
		}
                return array;
        }

	 public DefaultComboBoxModel getComboboxModel(){
            int i, tamanioLista;
                tamanioLista=this.listEmpleado.size();
		DefaultComboBoxModel modelo=new DefaultComboBoxModel();
		for(i=0;i<tamanioLista;i++) { 
			modelo.addElement(this.listEmpleado.get(i).getNombre()+" "+this.listEmpleado.get(i).getApellidos());
		}
                return modelo;
        }

   

}
