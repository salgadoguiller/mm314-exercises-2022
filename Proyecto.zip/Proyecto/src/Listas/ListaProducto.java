/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Listas;

import Clases.Producto;
import java.util.LinkedList;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author ACalix
 */
public class ListaProducto {
    private LinkedList<Producto> listProducto = new LinkedList<>();

    public ListaProducto() {
    }
    
    public boolean eliminar(int posicion) {
        listProducto.remove(posicion);
        return true;
    }
    public boolean modificar(Producto Modificado, int posicion) {
        listProducto.set(posicion, Modificado);
	return true;
    }
    
    public boolean agregar(Producto obje) {
        listProducto.add(obje);
        return true;
    }
    public Producto get(int posicion) {
        return listProducto.get(posicion);
    }
    public Object[][] getArrayGestion(){
        int i, tamanioLista;
        tamanioLista=this.listProducto.size();
        Object [][] array=new Object[tamanioLista][4];
        for(i=0;i<tamanioLista;i++) { 
            array[i][0]=this.listProducto.get(i).getCodigo();
            array[i][1]=this.listProducto.get(i).getNombre();
            array[i][2]=this.listProducto.get(i).getCategoria().getDescripcion();
            array[i][3]=this.listProducto.get(i).getPrecio();
        }
        return array;
    }
    public DefaultComboBoxModel getComboboxModel(){
        int i, tamanioLista;
        tamanioLista=this.listProducto.size();
	DefaultComboBoxModel modelo=new DefaultComboBoxModel();
	for(i=0;i<tamanioLista;i++) { 
	    modelo.addElement(this.listProducto.get(i).getNombre());
	}
        return modelo;
    }
}
